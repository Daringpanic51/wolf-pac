player_manager.AddValidModel("Ghost (Shiro)", "models/shiro/ghost.mdl");
player_manager.AddValidHands("Ghost (Shiro)", "models/shiro/ghost_vm.mdl", 0, "00000000");

--[[
COSMOS RP : 
Si vous voyez ce message, c'est que vous avez decompressé le fichier GMA de l'addon
Merci de ne pas utiliser ce modèle dans un pack d'addon mais d'utiliser le modèle source
Ne vous attribuez pas le mérite de la création de ce modèle, merci de respecter le travail fourni

Merci. - LightShoro
]]--

-- hook to replicate all bodygroups and skins to the hands

hook.Add("PreDrawPlayerHands", "ShiroGhostLoader - Replication", function(hands, vm, ply, wpn)
    if ply:GetModel() == "models/shiro/ghost.mdl" then
        if IsValid(hands) then
            
            for i = 0, ply:GetNumBodyGroups() - 1 do
                hands:SetBodygroup(i, ply:GetBodygroup(i))
            end

        end
    end
end)